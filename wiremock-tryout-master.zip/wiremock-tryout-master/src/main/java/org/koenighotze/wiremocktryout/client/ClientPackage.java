package org.koenighotze.wiremocktryout.client;

/**
 * Marker for package scan
 * @author David Schmitz
 */
public interface ClientPackage {
}
