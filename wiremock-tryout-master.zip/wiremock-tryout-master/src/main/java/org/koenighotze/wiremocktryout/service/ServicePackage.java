package org.koenighotze.wiremocktryout.service;

/**
 * Marker for package scan
 * @author David Schmitz
 */
public interface ServicePackage {
}
